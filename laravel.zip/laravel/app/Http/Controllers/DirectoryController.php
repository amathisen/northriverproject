<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;

class DirectoryController extends Controller
{

   //This function will grab the top level directory, so we can set levels when none is provided
    public function get_root_id() {
        
        $root_id = \DB::select('SELECT id FROM directory_contents WHERE is_directory = 1 AND fk_parent_id IS NULL');
        
        return $root_id[0]->id;
        
    }
    
    //Return the parent ID of a file or folder by supplying its ID
    //With more time I'd add in validation to make sure the parent exists and is a directory. Return error code on fail.
    public function get_parent_by_id($my_id) {
        
        $parent = \DB::select('SELECT fk_parent_id FROM directory_contents WHERE id = ' . $my_id);
        
        return $parent[0]->fk_parent_id;
    }
    
    //Get the contents of the current directory (level)
    //Again, validation here to ensure the provided ID exists would be nice
    public function get_db_contents($current_level) {
        
        $files = \DB::select('SELECT * FROM directory_contents WHERE id = ' . $current_level . ' OR fk_parent_id = ' . $current_level . ' ORDER BY is_directory DESC');
        
        return $files;
    }
    
    //Create a new entry by supplying a parent id (the folder it lives in), a name for the object, and its type (0 for file, 1 for folder)
    //All kinds of validation would go here (stuff exists, no sql injects by escaping stuff, etc)
    public function create_new($parent_id,$new_name,$new_type) {
        
        $new_name = trim($new_name);
        
        $test_exists = \DB::select('SELECT id FROM directory_contents WHERE name = \'' . $new_name . '\' AND fk_parent_id = ' . $parent_id);
        
        if(isset($test_exists[0]->id))
            $return_message = "A FILE OR FOLDER WITH THAT NAME ALREADY EXISTS IN THIS DIRECTORY :(";
        else {
            $new_file = \DB::insert('INSERT INTO directory_contents (fk_parent_id,name,is_directory) VALUES(' . $parent_id . ',\'' . trim($new_name) . '\',' . $new_type . ')');
            $return_message = "NEW OBJECT CREATED :)";
        }
        
        return $return_message;
    }
}
