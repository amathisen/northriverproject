<!DOCTYPE html>
<?php
    use App\Http\Controllers\DirectoryController;
    $dir_object = new DirectoryController;
 

    // Grab our current directory level, or the root level if none is supplied
    if(isset($_GET['level']))
        $level = $_GET['level'];
    else
        $level = $dir_object->get_root_id();

    //Check if we are doing an insert
    if(isset($_GET['new_name']) && trim(strlen($_GET['new_name'])) > 0)
        $new_message = $dir_object->create_new($level,$_GET['new_name'],$_GET['file_type']);

    //Grab the files/directories for display
    $files = $dir_object->get_db_contents($level);
?>

<html>
<head>
    <title>North River Project Directory View - Aaron Mathisen</title>
</head>
<body>
    <div>
        <table>
        <?php
            
            //Show the results of an attempted insert if one was attempted
            if(isset($new_message))
                echo "<tr><td><br /><br />" . $new_message . "<br /><br /></td><tr>";
        
            //Add in the 'go back a level' dot thingies
            if($level != $dir_object->get_root_id())
                echo '<tr><td><a href = ?level=' . $dir_object->get_parent_by_id($level) . '>..</a></td></tr>';
            
            //Total up our files and directories. We set directory_count to -1 so the current level doesn't count itself
            $file_count = 0;
            $directory_count = -1;
            
            //Loop over our list of files
            foreach($files as $this_file) {
                if($this_file->is_directory)
                    $directory_count++;
                else
                    $file_count++;
                    
                echo '<tr><td>';
                
                //Show directories as a link, and the current directory as bold
                if($this_file->is_directory == 1) {
                    if($this_file->id != $level)
                        echo "<a href = ?level=" . $this_file->id . ">";
                    else
                        $this_file->name = "<b>" . strtoupper($this_file->name) . " (current directory)</b>";
                    
                }
                
                echo $this_file->name;
                
                if($this_file->is_directory == 1)
                    echo "</a>";
                    
                echo "</td></tr>";
            }
        ?>
            
            <tr><td><br >File Count: <?php echo $file_count; ?></td></tr>
            <tr><td>Directory Count: <?php echo $directory_count; ?></td></tr>
        </table>
        
        <hr />
        <br />
        
        <!-- Form for adding new items into the current directory -->
        <table>
            <form action="?level=<?php echo $level; ?>">
                <input type="hidden" name="level" value="<?php echo $level; ?>">
                <tr><td><input type="text" name="new_name"></td></tr>
                <tr>
                    <td><input type="radio" name="file_type" value="0" CHECKED>File</td>
                    <td><input type="radio" name="file_type" value="1">Folder</td>
                </tr>
                <tr><td><input type="submit" value="Create New"></td></tr>
            </form>
        </table>
            
    </div>
</body>
</html>

<?

?>
